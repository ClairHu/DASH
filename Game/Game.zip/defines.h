#ifndef DEFINES_H
#define DEFINES_H

#define BAUD_RATE 9600
#define WAIT 800

#endif
